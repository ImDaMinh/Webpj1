import { useCallback } from "react";
import Particles from "react-tsparticles";

function ParticlesBackground() {
  const particlesInit = useCallback(async (engine) => {
    const { loadFull } = await import("tsparticles");
    await loadFull(engine);
  }, []);

  return (
    <Particles
      id="tsparticles"
      init={particlesInit}
      options={{
        fullScreen: { enable: false },
        background: { color: "transparent" },
        particles: {
          number: { value: 50 },
          color: { value: "#66ccff" },
          shape: { type: "circle" },
          opacity: { value: 0.5 },
          size: { value: 2 },
          links: {
            enable: true,
            distance: 120,
            color: "#66ccff",
            opacity: 0.4,
          },
          move: {
            enable: true,
            speed: 1,
            outModes: { default: "bounce" },
          },
        },
        interactivity: {
          events: {
            onHover: { enable: true, mode: "grab" },
            resize: true,
          },
        },
      }}
      style={{
        position: "absolute",
        top: 0,
        left: 0,
        width: "100%",
        height: "100%",
        zIndex: 1,
        pointerEvents: "none",
      }}
    />
  );
}

export default ParticlesBackground;
