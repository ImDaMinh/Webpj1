import './style.css';

function ProjectsPage() {
  return (
    <div className="projects-container">
      <h2>Các dự án cá nhân 💻</h2>
      <ul>
        <li>Dự án 1 – Web todo list</li>
        <li>Dự án 2 – Portfolio cá nhân</li>
        <li>Dự án 3 – Blog React Markdown</li>
      </ul>
    </div>
  );
}

export default ProjectsPage;
